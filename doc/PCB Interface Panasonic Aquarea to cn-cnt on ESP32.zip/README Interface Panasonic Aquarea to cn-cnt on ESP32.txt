            
How to use：

At editor EasyEDA https://u.easyeda.com , 
Creata new project,open the document via: Top menu - File - Open - EasyEDA... , and select the json file, then open it at the editor, you can save it into a project.


